# Leader-Board-
How to create the Leader Board using HTML CSS and Javascript - Tabbed Content in JS
